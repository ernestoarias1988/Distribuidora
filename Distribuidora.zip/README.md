## Features

-   Laravel based system
-   Bootstrap 
-   FontAwesome Icons
-   Responsive design
-   Stock control
-   Login and roles
-   Android app
