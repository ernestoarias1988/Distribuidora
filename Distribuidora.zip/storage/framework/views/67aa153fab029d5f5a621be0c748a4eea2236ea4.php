
<?php $__env->startSection("titulo", "Acumulado"); ?>
<?php $__env->startSection("contenido"); ?>
<?php
$productosAcum = array ();
$productosAcumCant = array ();
for($i=0; $i<100; $i++)
{
    $productosAcum[$i] = null;
    $productosAcumCant[$i] = null;
}

?>
    <div class="row">
        <div class="col-12">
            <h1>Acumulado de <?php echo e($vendedor); ?></h1>
            <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <h2>
            <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            if($venta->vendedor==$vendedor)
            {
                if($venta->entregado==0)
                {
                    foreach($venta->productos as $producto){
                        for($i=0; $i<100; $i++)
                        {
                          //  echo"ANTES DEL IF  $producto->descripcion == $productosAcum[$i] <br>";
                            if($producto->descripcion == $productosAcum[$i])
                            {
                                $productosAcumCant[$i] += $producto->cantidad;
                             //   echo"IF $productosAcum[$i] x $productosAcumCant[$i]<br>";
                                $i = 100;
                            }else{
                                if($productosAcum[$i] == null)
                                {                                  
                                    $productosAcumCant[$i] = $producto->cantidad;
                                    $productosAcum[$i] = $producto->descripcion;
                                //    echo"ELSE $productosAcum[$i] x $productosAcumCant[$i] <br>";
                                    $i = 100;
                                }
                            }
                        }
                    }                    
                }
            }
            ?>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
            for($i=0; $i<100; $i++)
            {
                if($productosAcum[$i]!= null)
                {
                    echo"$productosAcum[$i] x $productosAcumCant[$i] <br>"; 
                }
            }                               
            ?>
            </h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/totales/totales.blade.php ENDPATH**/ ?>