
<?php $__env->startSection("titulo", "Inicio"); ?>
<?php $__env->startSection('contenido'); ?>

<div class="col-12 text-center">
    <h1>Bienvenido, <?php echo e(Auth::user()->name); ?></h1>
    <?php if(Auth::user()->role_id=="1"): ?>
    <h1>Rol: Administrador</h1>
    <?php endif; ?>
</div>
<?php if(Auth::user()->role_id=="Administrador"): ?>
<?php $__currentLoopData = [
["productos", "vender","ventas", "clientes","usuarios"]
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-10 pb-2">
    <div class="row">
        <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-10 col-md-3">
            <div class="card">
                <img style="max-width:100%;width:auto;height:auto;" class="card-img-top" src="<?php echo e(url("/img/$modulo.png")); ?>">
                <div class="card-body">
                    <a href="<?php echo e(route("$modulo.index")); ?>" class="btn btn-success">
                        Ir a&nbsp;<?php echo e($modulo === "acerca_de" ? "Acerca de" : ucwords($modulo)); ?>

                        <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>



<?php if(Auth::user()->role_id=="Vendedor"): ?>
<?php $__currentLoopData = [
["ventas", "vender", "clientes"]
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-10 pb-2">
    <div class="row">
        <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-10 col-md-3">
            <div class="card">
                <img style="max-width:100%;width:auto;height:auto;" class="card-img-top" src="<?php echo e(url("/img/$modulo.png")); ?>">
                <div class="card-body">
                    <a href="<?php echo e(route("$modulo.index")); ?>" class="btn btn-success">
                        Ir a&nbsp;<?php echo e($modulo === "acerca_de" ? "Acerca de" : ucwords($modulo)); ?>

                        <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(Auth::user()->role_id=="Repartidor"): ?>
<?php $__currentLoopData = [
["ventas"]
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-10 pb-2">
    <div class="row">
        <?php $__currentLoopData = $modulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-10 col-md-3">
            <div class="card">
                <img style="max-width:100%;width:auto;height:auto;" class="card-img-top" src="<?php echo e(url("/img/$modulo.png")); ?>">
                <div class="card-body">
                    <a href="<?php echo e(route("$modulo.index")); ?>" class="btn btn-success">
                        Ir a&nbsp;<?php echo e($modulo === "acerca_de" ? "Acerca de" : ucwords($modulo)); ?>

                        <i class="fa fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<script>
    function message() {
        alert("Datos descargados!");
    }
</script>
<?php echo $__env->make('maestra', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/home.blade.php ENDPATH**/ ?>