
<?php $__env->startSection("titulo", "Detalle de venta "); ?>
<?php $__env->startSection("contenido"); ?>
<div class="row">
    <div class="col-12">
        <h1>Detalle de venta #<?php echo e($venta->id); ?></h1>
        <h1>Cliente: <small><?php echo e($venta->cliente->nombre); ?></small></h1>
        <h1>Direccion: <small><?php echo e($venta->cliente->direccion); ?></small></h1>
        <h1>Localidad: <small><?php echo e($venta->cliente->localidad); ?></small></h1>
        <h1>Vendedor: <small><?php echo e($venta->vendedor); ?></small></h1>
        <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a class="btn btn-info" href="<?php echo e(route("ventas.index")); ?>">
            <i class="fa fa-arrow-left"></i>&nbsp;Volver
        </a>
        <a class="btn btn-success" target="blank" href="<?php echo e(route("users.pdf", ["id"=>$venta->id])); ?>">
            <!--, ["id" => $venta->id]) -->
            <i class="fa fa-print"></i>&nbsp;PDF
        </a>
        <form action="<?php echo e(route("ventas.destroy", [$venta])); ?>" method="post">
            <?php echo method_field("delete"); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">
                <i class="fa fa-trash"></i>
                Eliminar Pedido
            </button>
        </form>
        <h2>Productos</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Descripción</th>
                    <th>Código de barras</th>
                    <th>Precio</th>
                    <th style="width: 10%;">Cantidad</th>
                    <th>Subtotal</th>
                    <th>Eliminar Producto</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($producto->descripcion); ?></td>
                    <td><?php echo e($producto->codigo_barras); ?></td>
                    <td>$<?php echo e(number_format($producto->precio, 2)); ?></td>
                    <td>
                        <form action="<?php echo e(route('cargaCantidadShow', ["id"=>$venta->id,"descripcion"=>$producto->descripcion])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo csrf_field(); ?>
                            <input type="number" step="0.1" $ required value="<?php echo e(number_format($producto->cantidad, 2)); ?>" required class="form-control" name="cantidad" id="cantidad" placeholder=""></p>
                        </form>
                    </td>
                    <td>$<?php echo e(number_format($producto->cantidad * $producto->precio, 2)); ?>

                    </td>
                    <td>
                        <?php echo method_field("post"); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fa fa-trash"></i>
                        </button>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"></td>
                    <td><strong>Total</strong></td>
                    <td>$<?php echo e(number_format($total, 2)); ?></td>
                </tr>
            </tfoot>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/ventas/ventas_show.blade.php ENDPATH**/ ?>