
<?php $__env->startSection("titulo", "Realizar venta"); ?>
<?php $__env->startSection("contenido"); ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="row">
    <div class="col-12">
        <h1>Nueva venta <i class="fa fa-cart-plus"></i></h1>
        <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-12">
            <div class="col-12 col-md-6">
                <form action="<?php echo e(route("guardarCliente")); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id_cliente">Cliente</label>
                        <input type="text" autocomplete="off" required class="form-control" name="id_cliente" id="id_cliente" placeholder="Ingrese el Cliente antes de finalizar la venta" />
                        <div id="clientelist">
                        </div>
                    </div>
                    <button name="accioncliente" type="submit" class="btn btn-primary">Seleccionar Cliente
                    </button>
            </div>
        </div>
        </form>
        <?php if(session("cliente") !== null): ?>
        <div class="col-12 col-md-6">
            <form action="<?php echo e(route("editaCantidad")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="descripcion">Producto</label>
                    <input type="text" name="codigo" autocomplete="off" id="codigo" class="form-control" required autofocus name="codigo" placeholder="Ingrese el producto" />
                    <div id="descripcionlist">
                    </div>
                </div>
                <div <p id="existencia">
                    </p>
                </div>
                <?php echo e(csrf_field()); ?>

                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="cantidad">Cantidad</label>
                    <input type="number" step="0.1" min="0" name="cantidad" autocomplete="off" id="cantidad" class="form-control" required autofocus name="cantidad" placeholder="Cantidad" />
                </div>
                <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-primary">Agregar Producto &nbsp;
                    <i class="fa fa-plus-square fa-2x" aria-hidden="true"></i> </button>
            </form>
        </div>
    </div>


</div>
<h2><br>Cliente: <?php echo e($cliente->nombre); ?> </h2>
<?php if(session("productos") !== null): ?>
<h2><br>Total:$<?php echo e(number_format($total, 2)); ?></h2>
<form action="<?php echo e(route("terminarOCancelarVenta")); ?>" method="post">
    <?php echo csrf_field(); ?>

    <div>
        <div class="form-group">
            <button name="accion" value="terminar" type="submit" class="btn btn-success">Terminar
                venta
            </button>
            <button name="accion" value="cancelar" type="submit" class="btn btn-danger">Cancelar
                venta
            </button>
        </div>
</form>
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Código de barras</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Total</th>
                <th>Quitar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = session("productos"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto->codigo_barras); ?></td>
                <td><?php echo e($producto->descripcion); ?></td>
                <td><?php $precioactual = 0; ?>
                    <?php if(session("cliente") !== null): ?>
                    <?php
                    if ($cliente) {
                        switch ($cliente->lista) {
                            case "1":
                                echo "$producto->precio_venta1";
                                $precioactual = $producto->precio_venta1;
                                break;

                            case "2":
                                echo "$producto->precio_venta2";
                                $precioactual = $producto->precio_venta2;
                                break;

                            case "3":
                                echo "$producto->precio_venta3";
                                $precioactual = $producto->precio_venta3;
                                break;
                        }
                    } else {
                        echo "Seleccione Cliente";
                    }
                    ?>
                    <?php endif; ?>
                    <?php if(session("cliente") == null): ?>
                    Seleccione Cliente
                    <?php endif; ?>
                </td>
                <td><?php echo e($producto->cantidad); ?></td>
                <td>
                    <?php
                    $total = $producto->cantidad * $precioactual;
                    echo "$" . $total . "";
                    ?>
                </td>
                <td>
                    <form action="<?php echo e(route("quitarProductoDeVenta")); ?>" method="post">
                        <?php echo method_field("delete"); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="indice" value="<?php echo e($loop->index); ?>">
                        <button type="submit" class="btn btn-danger">
                            <i class="fa fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>
<?php else: ?>
<h2>Aquí aparecerán los productos de la venta
    <br>
</h2>
<?php endif; ?>
</div>
</div>







<script>
    $('#codigo').ready(function() {

        $('#codigo').keyup(function() {
            var query = $(this).val();
            if (query != '') {
                var _token = $('input[name="_token"]').val();
                $.ajax({
                    url: "<?php echo e(route('autocomplete.fetch')); ?>",
                    method: "POST",
                    data: {
                        query: query,
                        _token: _token
                    },
                    success: function(data) {
                        $('#descripcionlist').fadeIn();
                        $('#descripcionlist').html(data);
                    }
                });
            }
        });

        $('#descripcionlist').on('click', 'li', function() {
            $('#codigo').val($(this).text());
            $('#descripcionlist').fadeOut();
        });


    });



    $('#descripcionlist').on('click', function() {
        var query = $(document.getElementById("codigo")).val();
        var _token = $('input[name="_token"]').val();
        $.ajax({
            url: "<?php echo e(route('autocomplete.fetchcantidad')); ?>",
            method: "POST",
            data: {
                query: query,
                _token: _token
            },
            success: function(data) {
                document.getElementById("existencia").textContent = data;
            }
        });
    });
</script>


<script>
    $('#id_cliente').ready(function() {

        $('#id_cliente').keyup(function() {
            var query = $(this).val();
            if (query != '') {
                var _token2 = $('input[name="_token"]').val();
                $.ajax({
                    url: "<?php echo e(route('autocomplete.fetchcliente')); ?>",
                    method: "POST",
                    data: {
                        query: query,
                        _token: _token2
                    },
                    success: function(data) {
                        $('#clientelist').fadeIn();
                        $('#clientelist').html(data);
                    }
                });
            }
        });

        $('#clientelist').on('click', 'li', function() {
            $('#id_cliente').val($(this).text());
            $('#clientelist').fadeOut();
        });

    });
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/vender/vender.blade.php ENDPATH**/ ?>