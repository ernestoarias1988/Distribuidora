
<?php $__env->startSection("titulo", "Ventas"); ?>
<?php $__env->startSection("contenido"); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<div class="row">
    <div class="col-12">
        <h1>Ventas <i class="fa fa-list"></i></h1>
        <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <a class="btn btn-primary" target="blank" style="margin-top:-0.5%" href="<?php echo e(route("ventas.pdf", ["id"=>$localidad])); ?>">
            <!--, ["id" => $venta->id]) -->
            <i class="fa fa-print"></i>&nbsp; Imprimir tickets
        </a>
        <button style="text-align:center" class="btn btn-success mb-2" onClick="window.location.href='https://localhost/Distribuidora/public/exportarv'">Exportar a Excel</button>
        <form action="<?php echo e(route("guardarLocalidad")); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" autocomplete="off" required class="form-control" name="id_localidad" id="id_localidad" placeholder="Ingrese Localidad" style="width:40% ;" />
                <div id="localidadlist">
                </div>
            </div>
            <button name="accionlocalidad" type="submit" class="btn btn-primary">Seleccionar Localidad
            </button>
    </div>
</div>
</form>
<?php if(session("localidad") !== null): ?>
<h4>Localidad:<?php echo e($localidad); ?> </h4>
<div class="row" style="margin: 0.2%;">
    <h4 id="showEntregado">Mostrar Entregados: <?php if($entregadosFlag==0): ?> NO <?php else: ?> SI <?php endif; ?></h4>
    <a class="btn btn-success" style="margin-left:0.2% ;" href="<?php echo e(route("ventas.indexSiShowEntregados")); ?>">
        <i class="fa fa-check"></i>
    </a>
    <a class="btn btn-danger" style="margin-left:0.2% ;" href="<?php echo e(route("ventas.indexNoShowEntregados")); ?>">
        <i class="fa fa-times"></i>
    </a>
</div>
<?php endif; ?>
<div style="text-align:center" class="table-responsive">
    <table class="table table-bordered table-striped table-highlight">
        <thead>
            <tr>
                <th white-space: nowrap;>Fecha</th>
                <th id="ventaslistado"><?php echo e($entregadosFlag); ?></th>
                <th>Total</th>
                <th style="width: 150px;">Pagado</th>
                <th>Diferencia</th>
                <th>Entregado</th>
                <th>Vendedor</th>
                <th>Detalles</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ventas->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($venta->cliente->localidad==$localidad && ($venta->entregado != 1 || $entregadosFlag == 1)) || $localidad==='Todas' || $localidad==null): ?>
            <?php if($venta->pagado==0): ?>
            <tr style="background-color: #faa;">
                <?php elseif($venta->pagado==$venta->total): ?>
            <tr style="background-color: #afa;">
                <?php elseif($venta->pagado>0): ?>
            <tr style="background-color: #ff4;">
                <?php endif; ?>
                <td><?php echo e($venta->created_at); ?></td>
                <td><?php echo e($venta->cliente->nombre); ?></td>
                <td>$<?php echo e(number_format($venta->total,2)); ?></td>
                <td>
                    <form action="<?php echo e(route('cargaPago', ['id'=>$venta->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo csrf_field(); ?>

                        <input type="number" step="0.1" $ required value="<?php echo e($venta->pagado); ?>" required class="form-control" name="pago" id="pago" placeholder=""></p>
                    </form>
                </td>

                <td>$<?php echo e(number_format($venta->total-$venta->pagado,2)); ?></td>
                <td>
                    <?php if($venta->entregado == 0): ?>

                    <a class="btn btn-danger" href="<?php echo e(route('cancelEntrega', ["id"=>$venta->id])); ?>">
                        <!--, ["id" => $venta->id]) -->
                        <i class="fa fa-times" aria-hidden="true"></i>

                    </a>
                    <?php else: ?>
                    <a class="btn btn-success" href="<?php echo e(route('cargaEntrega', ["id"=>$venta->id])); ?>">
                        <!--  ["id" => $venta->id]) -->
                        <i class="fa fa-check-square" aria-hidden="true"></i>

                    </a>
                    <?php endif; ?>
                </td>
                <td><a href="<?php echo e(route('totales.index', ["vendedor"=>$venta->vendedor])); ?>"> <?php echo e($venta->vendedor); ?></a></td>
                <td>
                    <a class="btn btn-success" href="<?php echo e(route("ventas.show", $venta)); ?>">
                        <i class="fa fa-info"></i>
                    </a>
                </td>


                <td>
                    <form action="<?php echo e(route("ventas.destroy", [$venta])); ?>" method="post">
                        <?php echo method_field("delete"); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="fa fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
</div>
<script>
    function message() {
        alert("Datos enviados!");
    }

    function showEntrega() {

        document.getElementById("showEntregado").innerHTML = "<?php $entregadosFlag = 1;
                                                                echo "Mostrar Entregados: SI";
                                                                ?>";
        document.getElementById("ventaslistado").contentWindow.location.reload(true);

        console.log("Refreshed SI");

    }

    function hideEntrega() {

        document.getElementById("showEntregado").innerHTML = "<?php $entregadosFlag = 0;
                                                                echo "Mostrar Entregados: NO";
                                                                ?>";


        console.log("Refreshed NO");

    }
</script>
<script>
    $('#id_localidad').ready(function() {

        $('#id_localidad').keyup(function() {
            var query = $(this).val();
            if (query != '') {
                var _token2 = $('input[name="_token"]').val();
                $.ajax({
                    url: "<?php echo e(route('autocomplete.fetchlocalidad')); ?>",
                    method: "POST",
                    data: {
                        query: query,
                        _token: _token2
                    },
                    success: function(data) {
                        $('#localidadlist').fadeIn();
                        $('#localidadlist').html(data);
                    }
                });
            }
        });

        $('#localidadlist').on('click', 'li', function() {
            $('#id_localidad').val($(this).text());
            $('#localidadlist').fadeOut();
        });

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/ventas/ventas_index.blade.php ENDPATH**/ ?>