

<?php $__env->startSection("titulo", "Agregar cliente"); ?>
<?php $__env->startSection("contenido"); ?>
    <div class="row">
        <div class="col-12">
            <h1>Agregar cliente</h1>
            <form method="POST" action="<?php echo e(route("clientes.store")); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="label">Nombre</label>
                    <input required autocomplete="off" name="nombre" class="form-control"
                           type="text" placeholder="Nombre">
                </div>
                <div class="form-group">
                    <label class="label">Teléfono</label>
                    <input required autocomplete="off" name="telefono" class="form-control"
                           type="number" placeholder="Teléfono">
                </div>                
                
                <div class="form-group">
                    <label class="label">Localidad</label>
                    <input required autocomplete="off" name="localidad" class="form-control"
                           type="text" placeholder="Localidad">
                </div>
                <div class="form-group">
                    <label class="label">Dirección</label>
                    <input required autocomplete="off" name="direccion" class="form-control"
                           type="text" placeholder="Dirección">
                </div>
                <div class="form-group">
                    <label class="label">Lista</label>
                    <select name="lista" id="lista" class="form-control <?php $__errorArgs = ['lista'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="lista" autofocus>
                             <option value="1">Lista 1</option> 
                             <option value="2">Lista 2</option> 
                            <option value="3">Lista 3</option>
                            </select>    
                </div>            

                <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button class="btn btn-success">Guardar</button>
                <a class="btn btn-primary" href="<?php echo e(route("clientes.index")); ?>">Volver al listado</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/clientes/clientes_create.blade.php ENDPATH**/ ?>