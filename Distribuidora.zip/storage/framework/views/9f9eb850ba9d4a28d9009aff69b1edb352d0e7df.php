<?php

use App\Venta;
use Illuminate\Http\Request;

//["ventas" => Venta::all()];
//$localidad = $data['localidad'];
$ventas = $data['ventas'];
$localidad = $data['localidad'];
$total = 0;
/*
$cliente = $data['cliente'];
$direccion = $data['direccion'];
$remitente = "Distribuidora";
$vendedor = $data['vendedor'];
$mensajePie = "Gracias por su compra!";
$numero = $data['facturaNro'];
$descuento = $data['descuento'];
//$porcentajeImpuestos = 16;
$fecha = date("Y-m-d");
*/
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <link rel="stylesheet" href="./bs3.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pedido</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xs-10 ">
                <h1></h1>
            </div>
            <?php $__currentLoopData = $ventas->sortBy('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($venta->cliente->localidad==$localidad || $localidad==='Todas' || $localidad==null) && $venta->entregado != 1): ?>
            <h4>Venta:#<?php echo e($venta->id); ?></h4>
            Vendedor:<?php echo e($venta->vendedor); ?><br>
            Cliente: <?php echo e($venta->cliente->nombre); ?><br>
            Direccion: <?php echo e($venta->cliente->direccion); ?> - Localidad: <?php echo e($venta->cliente->localidad); ?><br>
            <br>

            <table style="text-align: center; width:100%;">
                <thead>
                    <tr>
                        <th style="text-align:left">Descripción</th>
                        <th>Cantidad</th>
                        <th>Precio unitario</th>
                        <th>SubTotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align:left"><?php echo e($producto->descripcion); ?> </td>
                        <td> <?php echo e(number_format($producto->cantidad, 0)); ?> U. </td>
                        <td> $<?php echo e(number_format($producto->precio, 2)); ?></td>
                        <td> $<?php echo e(number_format($producto->cantidad * $producto->precio, 2)); ?></td>
                    </tr>
                    <?php $total += ($producto->cantidad * $producto->precio); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h4>Total: $<?php echo e(number_format($total, 2)); ?></h4>
            <?php $total = 0; ?>
            --------------------------------------------------------------------------------------------------<br>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</body>

</html><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/pdf/ventas.blade.php ENDPATH**/ ?>