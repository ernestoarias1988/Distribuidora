
<?php $__env->startSection("titulo", "Agregar usuario"); ?>
<?php $__env->startSection("contenido"); ?>
    <div class="row">
        <div class="col-12">
            <h1>Agregar usuario</h1>
            <form method="POST" action="<?php echo e(route("usuarios.store")); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="label">Nombre</label>
                    <input required autocomplete="off" name="name" class="form-control"
                           type="text" placeholder="Nombre">
                </div>
                <div class="form-group">
                    <label class="label">Usuario</label>
                    <input required autocomplete="off" name="email" class="form-control"
                           type="text" placeholder="Usuario">
                </div>
                <div class="form-group">
                <label class="label">Rol</label>
                <select name="role_id" id="role_id" class="form-control <?php $__errorArgs = ['role_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required autocomplete="role_id" autofocus>
                             <option value="Administrador">Administrador</option> 
                             <option value="Vendedor">Vendedor</option> 
                            <option value="Repartidor">Repartidor</option>
                            </select>

                </div>

                
                <div class="form-group">
                    <label class="label">Contraseña</label>
                    <input required autocomplete="off" name="password" class="form-control"
                           type="password" placeholder="Contraseña">
                </div>

                <?php echo $__env->make("notificacion", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button class="btn btn-success">Guardar</button>
                <a class="btn btn-primary" href="<?php echo e(route("usuarios.index")); ?>">Volver al listado</a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("maestra", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp7\htdocs\Distribuidora\resources\views/usuarios/usuarios_create.blade.php ENDPATH**/ ?>